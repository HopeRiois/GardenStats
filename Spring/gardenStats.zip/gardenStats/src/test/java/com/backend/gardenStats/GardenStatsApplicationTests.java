package com.backend.gardenStats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GardenStatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
